package com.learnJava.streams;

import com.learnJava.data.Student;
import com.learnJava.data.StudentDataBase;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import static java.time.temporal.ChronoUnit.DAYS;

public class StreamsExample {

    public static void main(String[] args) {

        //student name and there activities in a map
        Predicate<Student> studentPredicate = (student -> student.getGradeLevel()>=3);
        Predicate<Student> studentgpaPredicate = (student -> student.getGpa()>=3.9);


        Map<String,List<String>> studentMap = StudentDataBase.getAllStudents().stream()
                .filter(studentPredicate) //Stream<Students>
                .filter(studentgpaPredicate)//Stream<Students>
                .collect(Collectors.toMap(Student::getName,Student::getActivities)); //<Map>

        System.out.println(studentMap);

        LocalDate localDate = LocalDate.of(2018,06,24);
        System.out.println(localDate);
        LocalDate localDate1 = LocalDate.of(2018,06,20);

        System.out.println(localDate1.isBefore(localDate));

        System.out.println(DAYS.between(localDate1,localDate));
        System.out.println(DAYS.between(localDate,localDate1));
        IntStream.rangeClosed(0,(int) DAYS.between(localDate1,localDate))
                .forEach((i) -> {
                    System.out.println(localDate1.plusDays(i));
                });

        IntStream.rangeClosed(0,0)
                .forEach((i) -> {
                    System.out.println(localDate1.plusDays(i));
                });
    }
}
